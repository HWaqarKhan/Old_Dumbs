
var typed = new Typed('.Text-speed', {
    strings: ['transfer fee', 'long hold time', 'Innovators', 'Businusses', 'Entrepreneur', 'Startup', 'Bank'],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
  });
  