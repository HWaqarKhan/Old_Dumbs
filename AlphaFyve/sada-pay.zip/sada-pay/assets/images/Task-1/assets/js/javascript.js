// 1 let k itny kamal ahahaahhahahaha
let stringVar = "Hello World";
let numbVar = 42;
let boolVar = true;
let nullVar = true;
let objVar = { name: "Fiza", age: "50" };
let arrVar = [1, 2, 3];
function exfunction() {
    return "this is a function";
}
let uniquesymbol = Symbol("unique");
let currentdate = new Date();
let pattern = /abc/g;
let bigintvalue = BigInt(123456789102255678);

// sceen pr likhy ga

document.write("Heloo Fiza <br>");
var a = 10;
var c = 10.57;
var f = a + c;
var g = a - c;
var h=f-a;
document.write("Add a and c", f," <br>"  );

document.write("Add a and c", +f ," <br>");
document.write("sub a and c", g ," <br>");
document.write("sub a and c", h ," <br>");
document.getElementById("sumId").innerHTML="5";
console.log("a");
// Agr hum chaty han k jab hum yay wala function call kryn to text change hojy wo us paragraph k text ko replace krdy ga
let z = "Replaced Content";
document.getElementsByClassName("sumClass")[0].innerHTML = z;
document.querySelector("#sum").innerHTML="khadij";
 // Select an element by class
 const elementByClass = document.querySelector(".myClass");

 // Change the text content and add a class
 elementByClass.textContent = "Changed Text";
 elementByClass.classList.add("newClass");
// alert
// alert("Add a and c:" +f);
// window.alert("Add a and c:" +f);
// Functions
function myfunction()
{
document.getElementById("sumId1").innerHTML="Fiza";
document.getElementById("sumId2").innerHTML="Khadija";


}

