$(document).ready(function() {
  const intervalTime = 3000; // 3 seconds
  const $slides = $('.slide');
  let currentSlide = 0;

  function showSlide(index) {
    $slides.removeClass('active');
    $slides.eq(index).addClass('active');
  }

  function nextSlide() {
    currentSlide = (currentSlide + 1) % $slides.length;
    showSlide(currentSlide);
  }

  // Start the automatic rotation
  setInterval(nextSlide, intervalTime);
});
 
// var typed = new Typed(".Text-speed", {
//   String:["dfgdsadasjhgfa", "jasdgh", "skdhkh"],
//   typeSpeed: 100,
//   backSpeed: 100,
//   backDelay: 1000,
//   loop: true
// });
var typed = new Typed('.Text-speed', {
  strings: ['FineTechs', 'RegTechs', 'Innovators', 'Businusses', 'Entrepreneur', 'Startup', 'Bank'],
  typeSpeed: 100,
  backSpeed: 100,
  backDelay: 1000,
  loop: true
});


