from flask import Flask, render_template, request, send_from_directory
from restorer import ImageProcessor
from scratch import ScratchDetector
import os
import datetime
import sqlite3
import requests


class data_base:

    # creating models for data storage
    def __init__(self):
        with self.get_db_connection() as conn:
            conn.execute(
                """
            CREATE TABLE IF NOT EXISTS images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT
            )
            """
            )
            conn.commit()

    # making connection with SQLite database
    def get_db_connection(self):
        conn = sqlite3.connect('image.db')
        conn.row_factory = sqlite3.Row
        return conn

    # download image from image URL and save in database
    def save_image(self, img_url):
        response = requests.get(img_url)
        restored_image = response.content
        restored_image_folder = os.path.join('static', 'restored')
        time = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        filename = f"restored_{time}.png"
        restored_image_path = os.path.join(restored_image_folder, filename)

        with open(restored_image_path, 'wb') as image:
            image.write(restored_image)

        # Store the image data in the database
        with self.get_db_connection() as conn:
            conn.execute("INSERT INTO images (filename) VALUES (?)", (filename,))
            conn.commit()


class ImageApp:
    def __init__(self):
        # Create a new Flask application
        self.app = Flask(__name__)
        
        # Set up a folder uploaded Images
        self.upload_folder = os.path.join('static', 'uploads')
        self.app.config['UPLOAD_FOLDER'] = self.upload_folder

        # Set up a folder restored Images
        self.restored_folder = os.path.join('static', 'restored')
        self.app.config['RESTORED_FOLDER'] = self.restored_folder

        
        # Initialize an image processor
        self.image_processor = ImageProcessor()

        # Instance of data_base class
        self.restored_image = data_base()

        # Initialize scratch detector
        self.scratched_image = ScratchDetector()

        @self.app.route('/', methods=['GET', 'POST'])
        def home():
            uploaded_image = None
            restored_image = None
            scratched_image = None
            internet_connection_error=False 
            

            if request.method == 'POST':
                # Check if there's an internet connection
                if not self.image_processor.check_internet_connection():
                    return render_template('index.html', internet_connection_error=True)

                # check whether an option is selected or not
                selected_api = request.form.get('api_choice')
                if not selected_api:
                    return render_template('index.html', error = True)



                # Process the uploaded image
                uploaded_image, restored_image, scratched_image = self.process_image(request.files)
            return render_template('index.html', uploaded_image=uploaded_image, scratched_image=scratched_image , restored_image=restored_image,)

        @self.app.route('/restored_images')
        def restored_image():

            # comparing images of restored folder and database
            with self.restored_image.get_db_connection() as conn:
                image_data = conn.execute("SELECT filename FROM images").fetchall()
                # making a set of images found in database
                db_images = set(row[0] for row in image_data)

            restored_image_folder = os.path.join('static', 'restored')

            # making a set of images found in restored folder
            folder_images = set(os.listdir(restored_image_folder))

            deleted_images = db_images - folder_images
            # print(deleted_images)

            # if image from restored folder deleted, then corresponding field in database will also delete
            for filename in deleted_images:
                conn.execute("DELETE FROM images WHERE filename=?", (filename,))
                conn.commit()

            # Fetching all images data from the database
            with self.restored_image.get_db_connection() as conn:
                images = conn.execute("SELECT id, filename FROM images").fetchall()
            return render_template('restored.html', images=images)

        @self.app.route('/restored_images/<filename>')
        def uploaded_file(filename):
            return send_from_directory(self.app.config['RESTORED_FOLDER'], filename)


    def run(self):
        try:
            # Start the Flask application
            self.app.run(debug=True)
        except Exception as e:
            print(f"Error in ImageApp.run: {e}")

    def process_image(self, image):
        try:
            if 'image' not in image:
                return 'No file part', None

            image_file = image['image']
            if image_file.filename == '':
                return 'No selected file', None

            # Extract file details
            file = image_file.filename
            new_name = file.removesuffix('.png')
            time = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            file_name = f"{new_name}_{time}.png"
            file_path = os.path.join(self.app.config['UPLOAD_FOLDER'], file_name)
            image_file.save(file_path)

            # Restore the uploaded image using the image processor
            uploaded_image = f"/{self.app.config['UPLOAD_FOLDER']}/{file_name}"

            # get the scratch color
            color = request.form.get('color')

            scratched_image = self.scratched_image.index(file_path, color)

            selected_api = request.form.get('api_choice')

            if selected_api == '1':
                restored_image = self.image_processor.restore_image(file_path)

            if selected_api == '2':
                restored_image = self.image_processor.patch_remover(file_path)

            if selected_api == '3':
                restored_image = self.image_processor.patch_remover_hd(file_path)

        except Exception as e:
            # Log any errors that occur during image processing
            print(f"Error in ImageApp.process_image: {e}")
        return uploaded_image, restored_image, scratched_image


if __name__ == '__main__':

    app = ImageApp()
    app.run()
