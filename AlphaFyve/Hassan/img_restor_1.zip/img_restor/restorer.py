from dotenv import load_dotenv
import replicate
import requests
import tempfile

# Load environment variables
load_dotenv()

class ImageProcessor:

    # initializing model URLs of replicate APIs
    model_url = ["tencentarc/gfpgan:9283608cc6b7be6b65a8e44983db012355fde4132009bf99d976b2f0896856a3",
                 "microsoft/bringing-old-photos-back-to-life:c75db81db6cbd809d93cc3b7e7a088a351a3349c9fa02b6d393e35e0d51ba799"]

        # self.data = data_base()

    def restore_image(self, file_path):
        try:
             # Check if there's an internet connection
            if not self.check_internet_connection():
                return None, "No internet connection available"

            # Use the image processor to restore an image from the specified file path
            output = replicate.run(
                 self.model_url[0],
                 input={"img": open(file_path, "rb")}
            )

            # importing data_base class from app.py
            from app import data_base

            # an instance of data_base class
            self.data = data_base()

            # save image in restored folder and database
            self.data.save_image(output)

            return output

        except Exception as e:
            # Log any errors that occur during image restoration
            print(f"Error in ImageProcessor.restore_image: {e}")
            return None, f"Error during image restoration: {e}"

    def patch_remover(self, file_path):
        try:
             # Check if there's an internet connection
            if not self.check_internet_connection():
                return None, "No internet connection available"

            # Use the image processor to restore an image from the specified file path
            output = replicate.run(
                 self.model_url[1],
                 input={"image": open(file_path, "rb"), "with_scratch": True, "HR": True}
            )

            # importing data_base class from app.py
            from app import data_base

            # an instance of data_base class
            self.data = data_base()

            # save image in restored folder and database
            self.data.save_image(output)

            return output

        except Exception as e:
            # Log any errors that occur during image restoration
            print(f"Error in ImageProcessor.restore_image: {e}")
            return None, f"Error during image restoration: {e}"

    def patch_remover_hd(self, file_path):
        try:
             # Check if there's an internet connection
            if not self.check_internet_connection():
                return None, "No internet connection available"

            # Use the image processor to restore an image from the specified file path
            out = replicate.run(
                 self.model_url[1],
                 input={"image": open(file_path, "rb"), "with_scratch": True, "HR": True}
            )
            # downloading image from 'output' URL and saving in 'restored_images' folder
            response = requests.get(out)
            # Create a temporary file to save the restored image
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as temp_file:
                 temp_file.write(response.content)
                 temp_file_path = temp_file.name
            output = replicate.run(
                 self.model_url[0],
                 input={"img": open(temp_file_path, "rb")}
            )

            # importing data_base class from app.py
            from app import data_base

            # an instance of data_base class
            self.data = data_base()

            # save image in restored folder and database
            self.data.save_image(output)

            return output

        except Exception as e:
            # Log any errors that occur during image restoration
            print(f"Error in ImageProcessor.restore_image: {e}")
            return None, f"Error during image restoration: {e}"


    def check_internet_connection(self):
        try:
            # Attempt to make a simple HTTP request to check for internet connection
            requests.get('http://www.google.com', timeout=1)
            return True
        except requests.ConnectionError:
            return False