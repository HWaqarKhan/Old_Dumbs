import cv2
import numpy as np
import os

class ScratchDetector:

    def index(self, image, color):

        # Default color for lower bound
        default_lower_color = '#E2CDA1'

        # Check if the color not provided, then use the default color
        if not color:
            lower_color = default_lower_color
        else:
            lower_color = color

        # Convert the hexadecimal lower color bound to BGR format
        bgr_lower = self.hex_to_bgr(lower_color)

        # Load the image to OpenCV
        image = cv2.imread(image)

        # Define the upper color bound: default White
        upper_color = "#ffffff"
        # Convert the hexadecimal upper color bound to BGR format
        bgr_upper = self.hex_to_bgr(upper_color)

        # Creating mask to identify scars based on the color range
        mask = cv2.inRange(image, bgr_lower, bgr_upper)

        highlighted_image = image.copy()

        # Replace the pixels in the highlighted_image with red
        highlighted_image[mask != 0] = (0, 0, 255)

        # converting binary data to actual image
        _, img_encoded = cv2.imencode('.jpg', highlighted_image)
        scratched_image = img_encoded.tobytes()

        # temporarily save image in scratches folder
        # this image will overwrite when new image is processed
        scratched_image_folder = os.path.join('static', 'scratches')
        scratched_image_path = os.path.join(scratched_image_folder, 'scratches_mask.png')
        with open(scratched_image_path, 'wb') as image_file:
            image_file.write(scratched_image)

        # returns path to the temporary image
        return scratched_image_path

    # Custom function which converts hexadecimal color code to BGR format
    def hex_to_bgr(self, hex_color):
        hex_color = hex_color.lstrip('#')
        if len(hex_color) == 3:
            hex_color = ''.join([x * 2 for x in hex_color])
        bgr_values = [int(hex_color[i:i+2], 16) for i in (4, 2, 0)]
        # return color to numpy's readable format
        return np.array(bgr_values, dtype=np.uint8)
