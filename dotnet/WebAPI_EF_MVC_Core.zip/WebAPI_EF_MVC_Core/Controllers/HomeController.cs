﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPI_EF_MVC_Core.Models;
using System.Net.Http;
using Newtonsoft.Json;

namespace WebAPI_EF_MVC_Core.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public IActionResult Index()
        {
            List<CustomerModel> customers = SearchCustomers("");
            return View(customers);
        }

        [HttpPost]
        public IActionResult Index(string name)
        {
            List<CustomerModel> customers = SearchCustomers(name);
            return View(customers);
        }

        private static List<CustomerModel> SearchCustomers(string name)
        {
            List<CustomerModel> customers = new List<CustomerModel>();
            string apiUrl = "https://localhost:44318/api/CustomerAPI";

            HttpClient client = new HttpClient();
            HttpResponseMessage response = client.GetAsync(apiUrl + string.Format("/GetCustomers?name={0}", name)).Result;
            if (response.IsSuccessStatusCode)
            {
                customers = JsonConvert.DeserializeObject<List<CustomerModel>>(response.Content.ReadAsStringAsync().Result);
            }

            return customers;
        }
    }
}